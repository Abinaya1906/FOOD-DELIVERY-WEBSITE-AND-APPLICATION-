import { createContext } from "react";
const LoadingContext = createContext();
export default LoadingContext;
